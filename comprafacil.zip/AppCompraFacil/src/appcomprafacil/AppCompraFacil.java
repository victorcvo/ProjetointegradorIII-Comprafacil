/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package appcomprafacil;

import appcomprafacil.classes.AGENDAMENTO;
import appcomprafacil.classes.Compra_Vendas;
import appcomprafacil.classes.Emitente;
import appcomprafacil.classes.MOVIMENTO_FINANCEIRO;
import javax.swing.JOptionPane;
/**
 *
 * @author Victor
 */
public class AppCompraFacil {
  
    /**
     * @param args the command line arguments
     */

    public static void main(String[] args) {
        // TODO code application logic here
        //Cadastro de Clientes / Fornecedores
        
      variaveisGlobal_CPF.global = JOptionPane.showInputDialog("Digite seu cpf:");
       variaveisGlobal_NOME.global = JOptionPane.showInputDialog("Digite seu nome");
      variaveisGlobal_ENDERECO.global= JOptionPane.showInputDialog("Digite o Endereço");
       variaveisGlobal_CIDADE.global= JOptionPane.showInputDialog("Digite o Cidade");
       variaveisGlobal_UF.global = JOptionPane.showInputDialog("Digite UF");
      variaveisGlobal_PAIS.global  = JOptionPane.showInputDialog("Digite o Pais");
      //JOptionPane.QUESTION_MESSAGE(variaveisGlobal_CPF.global);
              
        //JOptionPane.INFORMATION_MESSAGE(null,variaveisGlobal_CPF.global);
      JOptionPane.showMessageDialog(null,"Produto escolhido: Guarana Mate Couro ----- Valor Unitario: R$ 10,00");           
      JOptionPane.showMessageDialog(null,"Quantidade escolhida: 50 unidades");  
      variaveisGlobal_QUANTIDADE.global = 50;
     StringBuilder mensagem = new StringBuilder();

    //nome = JOptionPane.showInputDialog("Digite seu nome:");
    mensagem.append("O total é R$").append(variaveisGlobal_TOTAL.global).append("!");
    JOptionPane.showMessageDialog(null, mensagem);
             
{
        Emitente emitente = new Emitente(variaveisGlobal_CPF.global,variaveisGlobal_NOME.global,variaveisGlobal_ENDERECO.global,variaveisGlobal_CIDADE.global,variaveisGlobal_UF.global,variaveisGlobal_PAIS.global);
        emitente.conscad();
        Compra_Vendas compra_vendas = new Compra_Vendas (00001,"06/06/2020",variaveisGlobal_CPF.global,variaveisGlobal_PRODUTO.global,variaveisGlobal_VALORUNITARIO.global ,variaveisGlobal_QUANTIDADE.global);
        compra_vendas.consmovnota();
        MOVIMENTO_FINANCEIRO movimento_financeiro = new MOVIMENTO_FINANCEIRO(00001,"06/06/2020",variaveisGlobal_CPF.global,1,variaveisGlobal_TOTAL.global,"06/07/2020");
        movimento_financeiro.consmovfinanceiro();
              AGENDAMENTO agendamento = new AGENDAMENTO(00001,"06/06/2020",variaveisGlobal_CPF.global,"06/06/2020","15:35");
        agendamento.consagendamento();
        
    }
     
    
}
}

