/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package appcomprafacil.classes;
import appcomprafacil.classes.Compra_Vendas;
import appcomprafacil.AppCompraFacil;
/**
 *
 * @author Victor
 */
public class AGENDAMENTO {
  private int NOTA_FISCA;

	private String DATA_MOV ;

	private String CPF_CNPJ ;
	     
        private String DATA;
        
        private String HORA;
        
      public AGENDAMENTO (int NOTA_FISCA,String DATA_MOV,String CPF_CNPJ,String DATA,String HORA){
          this.NOTA_FISCA = NOTA_FISCA;
          this.DATA_MOV = DATA_MOV;
            this.CPF_CNPJ = CPF_CNPJ;
            this.DATA = DATA;
            this.HORA = HORA;
      }
          public void consagendamento(){
       System.out.println("======================================= " );
       System.out.println("NOTA FISCAL : " + NOTA_FISCA);
       System.out.println("DATA DA NOTA : " +DATA_MOV);
       System.out.println("CPF : " + CPF_CNPJ);
       System.out.println("DATA DA ENTREGA " + DATA);
       System.out.println("HORA DA ENTREGA " + HORA);
       System.out.println("======================================= " );
   }
      
}
