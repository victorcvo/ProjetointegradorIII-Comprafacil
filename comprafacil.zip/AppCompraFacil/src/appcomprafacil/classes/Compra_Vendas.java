/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package appcomprafacil.classes;

/**
 *
 * @author Victor
 */
public class Compra_Vendas {
    
       
        private int NOTA_FISCA;

	private String DATA_MOV ;

	private String CPF_CNPJ;

	private String COD_PRODUTO;

	private double QUANTIDADE;
        
        private double VALORUNITARIO;

	//private double TOTAL;

    public Compra_Vendas (int NOTA_FISCA,String DATA_MOV,String CPF_CNPJ,String COD_PRODUTO,double QUANTIDADE,double VALORUNITARIO){ 
     
    
    this.NOTA_FISCA = NOTA_FISCA;
     this.DATA_MOV = DATA_MOV;
      this.CPF_CNPJ = CPF_CNPJ;
       this.COD_PRODUTO = COD_PRODUTO;
        this.VALORUNITARIO=VALORUNITARIO;
        this.QUANTIDADE = QUANTIDADE;
       // this.TOTAL =QUANTIDADE * VALORUNITARIO;
    }  
    public int sequencia =  1+1;
   public void consmovnota(){
       System.out.println("======================================= " );
       System.out.println("NOTA FISCAL : " + NOTA_FISCA);
       System.out.println("DATA : " + DATA_MOV);
       System.out.println("CPF : " + CPF_CNPJ);
       System.out.println("CODIGO : " + COD_PRODUTO);
       System.out.println(String.format("VALOR UNITARIO : R$%.2f ",  VALORUNITARIO));
       System.out.println(String.format("QUANTIDADE: %.2f  ",  QUANTIDADE));
       System.out.println(String.format("TOTAL: R$%.2f ", VALORUNITARIO * QUANTIDADE));
       System.out.println("======================================= " );
   }
   

}
