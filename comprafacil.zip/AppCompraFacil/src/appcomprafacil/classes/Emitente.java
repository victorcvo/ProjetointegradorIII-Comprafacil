/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package appcomprafacil.classes;

/**
 *
 * @author Victor
 */
public class Emitente {
    
      
       
        private String CPF_CNPJ;

	private String NOME_PESSOA_PF_PJ;

	private String ENDERECO;

	private String CIDADE;

	private String UF;

	private String PAIS;

    public Emitente (String CPF_CNPJ, String NOME_PESSOA_PF_PJ,String ENDERECO,String CIDADE,String UF,String PAIS){ 
     
    
    this.CPF_CNPJ = CPF_CNPJ;
    this.NOME_PESSOA_PF_PJ = NOME_PESSOA_PF_PJ;
    this.ENDERECO = ENDERECO;
    this.CIDADE = CIDADE;
    this.PAIS = PAIS;
    this.UF = UF;
    }  
    
   public void conscad(){
       System.out.println("======================================= " );
       System.out.println("CPF : " + CPF_CNPJ);
       System.out.println("NOME : " + NOME_PESSOA_PF_PJ);
       System.out.println("ENDEREÇO : " + ENDERECO);
       System.out.println("CIDADE : " + CIDADE);
       System.out.println("UF : " + UF );
       System.out.println("PAIS : " + PAIS);
       System.out.println("======================================= " );
       
   }
   
}