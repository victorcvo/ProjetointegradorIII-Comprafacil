/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package appcomprafacil.classes;

/**
 *
 * @author Victor
 */
public class MOVIMENTO_FINANCEIRO {
    private int NOTA_FISCA;

	private String DATA_MOV ;

	private String CPF_CNPJ;
	     
        private int PARCELA;
        
        private double VALOR_PARCELA;
        
        private String DATA_VENCIMENTO;
        
        public MOVIMENTO_FINANCEIRO(int NOTA_FISCA,String DATA_MOV,String CPF_CNPJ,int PARCELA,double VALOR_PARCELA,String DATA_VENCIMENTO ){

          this.NOTA_FISCA = NOTA_FISCA;
          this.DATA_MOV = DATA_MOV;
          this.CPF_CNPJ = CPF_CNPJ;
          this.PARCELA = PARCELA;
          this.VALOR_PARCELA = VALOR_PARCELA;
          this.DATA_VENCIMENTO = DATA_VENCIMENTO;
}
        public void consmovfinanceiro(){
       System.out.println("======================================= " );
       System.out.println("NOTA FISCAL: " + NOTA_FISCA);
       System.out.println("DATA NOTA: " + DATA_MOV);
       System.out.println("CPF : " + CPF_CNPJ);
       System.out.println("PARCELA : " + PARCELA);
       System.out.println(String.format("VALOR DA PARCELA : R$%.2f ",  VALOR_PARCELA));
        System.out.println("DATA VENCIMENTO : " + DATA_VENCIMENTO);
       System.out.println("======================================= " );
}

}