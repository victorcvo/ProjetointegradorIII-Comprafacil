/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package appcomprafacil.classes;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Victor
 */
public class Compra_VendasTest {
    
    public Compra_VendasTest() {
    }

    /**
     * Test of consmovnota method, of class Compra_Vendas.
     */
    @Test
    public void testConsmovnota() {
        System.out.println("consmovnota");
        Compra_Vendas instance = null;
        instance.consmovnota();
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }
    
}
