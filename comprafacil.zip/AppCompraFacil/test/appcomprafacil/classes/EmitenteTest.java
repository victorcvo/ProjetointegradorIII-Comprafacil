/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package appcomprafacil.classes;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Victor
 */
public class EmitenteTest {
    
    public EmitenteTest() {
    }

    /**
     * Test of conscad method, of class Emitente.
     */
    @Test
    public void testConscad() {
        System.out.println("conscad");
        Emitente instance = null;
        instance.conscad();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
