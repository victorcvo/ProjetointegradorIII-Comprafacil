/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package appcomprafacil.classes;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Victor
 */
public class MOVIMENTO_FINANCEIROTest {
    
    public MOVIMENTO_FINANCEIROTest() {
    }

    /**
     * Test of consmovfinanceiro method, of class MOVIMENTO_FINANCEIRO.
     */
    @Test
    public void testConsmovfinanceiro() {
        System.out.println("consmovfinanceiro");
        MOVIMENTO_FINANCEIRO instance = null;
        instance.consmovfinanceiro();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
